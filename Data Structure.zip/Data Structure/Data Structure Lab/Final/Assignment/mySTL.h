#include <iostream>
using namespace std;

class SingleLinkedList

{
// Single Linked List
    int data;
    SingleLinkedList *next; // Pointer to next node
public:
    void insertAtLast(int d)
    {
    }

    void insertAtFirst(int d)
    {
    }

    void insertAtAnyPos(int d, int pos)
    {
    }

    void insertBeforeElement(int d, int e)
    {
    }

    void displayList()
    {
    }

    void deleteElementByValue(int d)
    {
    }

    void deleteAtPos(int pos)
    {
    }

    void displayList()
{

}

};



class DoubleLinkedList
{                           // Double Linked List
    int data;               // Data
    DoubleLinkedList *next; // Pointer to next node
    DoubleLinkedList *prev; // Pointer to previous node
public:
    void insertAtLast(int d)
    {
    }

    void insertAtFirst(int d)
    {
    }

    void insertAtAnyPos(int d, int pos)
    {
    }

    void insertBeforeElement(int d, int e)
    {
    }

    void displayList()
    {
    }

    void deleteElementByValue(int d)
    {
    }

    void deleteAtPos(int pos)
    {
    }

    void displayList()
{

}


};


// Node class for the linked list
class Node
{
public:
    int data;
    Node* next;

    Node(int data)
    {
        this->data = data;
        this->next = nullptr;
    }
};

// Stack class using linked list
class Stack
{
private:
    Node* topNode;
public:
    Stack()
    {
        topNode = nullptr;
    }

    void push(int data)
    {

    }

    int pop()
    {

    }

    int top()
    {

    }
};

// Queue class using linked list
class Queue
{
private:
    Node* frontNode;
    Node* rearNode;
public:
    Queue()
    {
        frontNode = nullptr;
        rearNode = nullptr;
    }

    void enqueue(int data)
    {

    }

    int dequeue()
    {

    }

    int front()
    {

    }

    int rear()
    {

    }
};



class TreeNode
{
public:
    int val;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) : val(val), left(nullptr), right(nullptr) {}
};

class BST
{
private:
    TreeNode* root;

public:
    BST() : root(nullptr) {}

    void insertIntoBST(int val)
    {

    }

    TreeNode* searchInBST(int val)
    {

    }

    void displayInorder(TreeNode* node)
    {

    }

    void displayInorder()
    {

    }

    void displayPreorder(TreeNode* node)
    {

    }

    void displayPreorder()
    {

    }

    void displayPostorder(TreeNode* node)
    {

    }

    void displayPostorder()
    {

    }
};

int main()
{
    BST tree;
    tree.insertIntoBST(5);
    tree.insertIntoBST(3);
    tree.insertIntoBST(7);
    tree.insertIntoBST(1);
    tree.insertIntoBST(9);

    TreeNode* found = tree.searchInBST(3);
    if (found != nullptr)
    {
        cout << "Found value: " << found->val << endl;
    }

    else
    {
        cout << "Value not found" << endl;
    }

    cout << "In-order traversal: ";
    tree.displayInorder();

    cout << "Pre-order traversal: ";
    tree.displayPreorder();

    cout << "Post-order traversal: ";
    tree.displayPostorder();

    return 0;
}

