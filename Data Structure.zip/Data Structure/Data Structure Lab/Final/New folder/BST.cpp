#include <iostream>
using namespace std;

// Node class
class Node {
public:
    int data;
    Node* left;
    Node* right;

    Node(int data) {
        this->data = data;
        this->left = NULL;
        this->right = NULL;
    }
};

// BST class
class BinarySearchTree {
private:
    Node* root;

    // Recursive helper function to insert a node into the BST
    Node* insert_helper(Node* node, int data) {
        if (node == NULL) {
            node = new Node(data);
            return node;
        }

        if (data < node->data) {
            node->left = insert_helper(node->left, data);
        } else if (data > node->data) {
            node->right = insert_helper(node->right, data);
        }

        return node;
    }

    // Recursive helper function to traverse the BST in order and print the nodes
    void inorder_helper(Node* node) {
        if (node == NULL) {
            return;
        }

        inorder_helper(node->left);
        cout << node->data << " ";
        inorder_helper(node->right);
    }

public:
    BinarySearchTree() {
        root = NULL;
    }

    // Method to insert a node into the BST
    void insert(int data) {
        root = insert_helper(root, data);
    }

    // Method to traverse the BST in order and print the nodes
    void inorder() {
        inorder_helper(root);
        cout << endl;
    }
};

// Main function to test the implementation
int main() {
    BinarySearchTree bst;

    bst.insert(5);
    bst.insert(3);
    bst.insert(7);
    bst.insert(1);
    bst.insert(9);

    bst.inorder();

    return 0;
}
