#include <iostream>
using namespace std;

// Node class
class Node {
public:
    int data;
    Node* next;
};

// Singly linked list class
class SinglyLinkedList {
private:
    Node* head;
public:
    SinglyLinkedList() {
        head = NULL;
    }

    // Add a node to the end of the list
    void append(int data) {
        Node* new_node = new Node();
        new_node->data = data;
        new_node->next = NULL;

        if (head == NULL) {
            head = new_node;
            return;
        }

        Node* current = head;
        while (current->next != NULL) {
            current = current->next;
        }

        current->next = new_node;
    }

    // Print the list
    void print() {
        Node* current = head;
        while (current != NULL) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }
};

// Main function to test the implementation
int main() {
    SinglyLinkedList list;

    list.append(1);
    list.append(2);
    list.append(3);

    list.print();

    return 0;
}
