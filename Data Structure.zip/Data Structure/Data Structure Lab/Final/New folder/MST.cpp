#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

// Edge class
class Edge {
public:
    int src, dest, weight;
};

// Graph class
class Graph {
public:
    int V, E;
    vector<Edge> edges;

    // Constructor
    Graph(int V, int E) {
        this->V = V;
        this->E = E;
    }

    // Method to add an edge to the graph
    void add_edge(int src, int dest, int weight) {
        Edge edge;
        edge.src = src;
        edge.dest = dest;
        edge.weight = weight;
        edges.push_back(edge);
    }

    // Method to find the parent of a vertex
    int find_parent(int parent[], int i) {
        if (parent[i] == i) {
            return i;
        }

        return find_parent(parent, parent[i]);
    }

    // Method to perform union of two subsets
    void union_sets(int parent[], int rank[], int x, int y) {
        int x_root = find_parent(parent, x);
        int y_root = find_parent(parent, y);

        if (rank[x_root] < rank[y_root]) {
            parent[x_root] = y_root;
        } else if (rank[x_root] > rank[y_root]) {
            parent[y_root] = x_root;
        } else {
            parent[y_root] = x_root;
            rank[x_root]++;
        }
    }

    // Method to perform Kruskal's algorithm to find MST
    void kruskal_mst() {
        vector<Edge> result(V-1);

        // Sort edges by weight
        sort(edges.begin(), edges.end(), [](Edge a, Edge b) {
            return a.weight < b.weight;
        });

        int* parent = new int[V];
        int* rank = new int[V];

        for (int i = 0; i < V; i++) {
            parent[i] = i;
            rank[i] = 0;
        }

        int i = 0, e = 0;
        while (e < V-1 && i < E) {
            Edge next_edge = edges[i++];

            int x = find_parent(parent, next_edge.src);
            int y = find_parent(parent, next_edge.dest);

            if (x != y) {
                result[e++] = next_edge;
                union_sets(parent, rank, x, y);
            }
        }

        // Print the edges of the MST
        cout << "Minimum Spanning Tree:" << endl;
        for (i = 0; i < V-1; i++) {
            cout << result[i].src << " - " << result[i].dest << " : " << result[i].weight << endl;
        }
    }
};

// Main function to test the implementation
int main() {
    int V = 4; // number of vertices
    int E = 5; // number of edges

    Graph graph(V, E);

    // Add edges to the graph
    graph.add_edge(0, 1, 10);
    graph.add_edge(0, 2, 6);
    graph.add_edge(0, 3, 5);
    graph.add_edge(1, 3, 15);
    graph.add_edge(2, 3, 4);

    graph.kruskal_mst();

    return 0;
}
