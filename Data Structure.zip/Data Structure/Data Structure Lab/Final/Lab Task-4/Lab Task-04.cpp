#include <iostream>
using namespace std;

// Definition of a node in BST
struct Node
{
    int data;
    Node* left;
    Node* right;
};

// Function to create a new node with given data
Node* newNode(int data)
{
    Node* newNode = new Node;
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}


// Function to insert a value in BST
Node* insertIntoBST(Node* root, int value)
{
    if (root == NULL)
    {
        root = newNode(value);
    }

    else if (value <= root->data)

    {
        root->left = insertIntoBST(root->left, value);
    }

    else
    {
        root->right = insertIntoBST(root->right, value);
    }
    return root;
}

// Function to search for a value in BST
bool searchInBST(Node* root, int value)
{
    if (root == NULL)
    {
        return false;
    }

    else if (root->data == value)
    {
        return true;
    }

    else if (value < root->data)
    {
        return searchInBST(root->left, value);
    }

    else
    {
        return searchInBST(root->right, value);
    }
}

// Function to find minimum value in BST
int findMinInBST(Node* root)
{
    if (root == NULL)
    {
        cout << "Error: Tree is empty\n";
        return -1;
    }

    else if (root->left == NULL)
    {
        return root->data;
    }

    else
    {
        return findMinInBST(root->left);
    }
}

// Function to find maximum value in BST
int findMaxInBST(Node* root)
{
    if (root == NULL)
    {
        cout << "Error: Tree is empty\n";
        return -1;
    }

    else if (root->right == NULL)
    {
        return root->data;
    }

    else
    {
        return findMaxInBST(root->right);
    }
}

// Function to print the values of BST in inorder traversal
void inorder(Node* root)
{
    if (root == NULL)
    {
        return;
    }
    inorder(root->left);
    cout << root->data << " ";
    inorder(root->right);
}

// Function to print the values of BST in preorder traversal
void preorder(Node* root)
{
    if (root == NULL)
    {
        return;
    }
    cout << root->data << " ";
    preorder(root->left);
    preorder(root->right);
}

// Function to print the values of BST in postorder traversal
void postorder(Node* root)
{
    if (root == NULL)
    {
        return;
    }
    postorder(root->left);
    postorder(root->right);
    cout << root->data << " ";
}

// Function to delete a node with given value from BST
Node* deleteFromBST(Node* root, int value)
{
    if (root == NULL)
    {
        return root;
    }

    else if (value < root->data)
    {
        root->left = deleteFromBST(root->left, value);
    }

    else if (value > root->data)
    {
        root->right = deleteFromBST(root->right, value);
    }

    else
        {
        if (root->left == NULL && root->right == NULL)
        {
            delete root;
            root = NULL;
        }

        else if (root->left == NULL)
            {
            Node* temp = root;
            root = root->right;
            delete temp;

            }
        else if (root->right == NULL)
        {
            Node* temp = root;
            root = root->left;
            delete temp;
        }
        else
        {
            int minValue = findMinInBST(root->right);
            root->data = minValue;
            root->right = deleteFromBST(root->right, minValue);
        }
    }
    return root;
}

// Function to test the BST operations
int main()
{
    Node* root = NULL;
    root = insertIntoBST(root, 50);
    root = insertIntoBST(root, 30);
    root = insertIntoBST(root, 70);
    root = insertIntoBST(root, 20);
    root = insertIntoBST(root, 40);
    root = insertIntoBST(root, 60);
    root = insertIntoBST(root, 80);

    cout << "Inorder traversal: ";
    inorder(root);
    cout << endl;

    cout << "Preorder traversal: ";
    preorder(root);
    cout << endl;

    cout << "Postorder traversal: ";
    postorder(root);
    cout << endl;

    cout << "Min value: " << findMinInBST(root) << endl;
    cout << "Max value: " << findMaxInBST(root) << endl;

    int valueToSearch = 30;
    if (searchInBST(root, valueToSearch))
    {
        cout << "Value " << valueToSearch << " found in BST\n";
    }

    else
    {
        cout << "Value " << valueToSearch << " not found in BST\n";
    }

    int valueToDelete = 50;
    root = deleteFromBST(root, valueToDelete);
    cout << "After deleting " << valueToDelete << ": ";
    inorder(root);
    cout << endl;

    return 0;
}
