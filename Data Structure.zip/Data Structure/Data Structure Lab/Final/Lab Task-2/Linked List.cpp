#include<iostream>
using namespace std;

//Structure for the Node
typedef class Node

{
public:
    int data;
    Node *next;
    Node()
    {
    }

    Node(int value)
    {
        data = value;
        next = NULL;
    }
}* NodePointer;


//Declaring and initializing head and current node
NodePointer head=NULL,curr=NULL;

//Creating a Node with given value
NodePointer createNewNode(int value)
{
    NodePointer node = new Node();
    node->data = value;
    node->next = NULL;
    return node;
}

//insertion of N elements for the first time
void insertNelements(int n)
{
    int value;
    for(int i=1;i<=n;i++)
        {
        cout<<"Enter value "<<i<<": ";
        cin>>value;
        NodePointer node = createNewNode(value);
        if(head == NULL)
        {
            head = node;
            curr = head;
        }

        else
        {
            curr->next = node;
            curr = node;
        }
    }
}


//insert a value as node at the Beginning of Linked List
void insertAtFirst(int value)
{
    NodePointer node = createNewNode(value);
    if(head == NULL)
    {
        head = node;
        curr = head;
    }

    else
    {
        node->next = head;
        head = node;
    }
}


//insert a value as node at the End of Linked List
void insertAtLast(int value)
{
    NodePointer node = createNewNode(value);
    if(head == NULL)
    {
        head = node;
        curr = head;
    }

    else
    {
        curr->next = node;
        curr = node;
    }
}


void insertBefore(int value, int p)
{
    if(head == NULL)
    {
        cout<<"List is empty"<<endl;
        return;
    }

    NodePointer node = createNewNode(value);
    NodePointer prev = NULL;
    NodePointer current = head;
    while(current != NULL && current->data != p)
    {
        prev = current;
        current = current->next;
    }

    if(current == NULL)
    {
        cout<<"Value "<<p<<" not found in the list"<<endl;
        return;
    }

    if(prev == NULL)

    {
        node->next = head;
        head = node;
    }

    else
    {
        node->next = prev->next;
        prev->next = node;
    }
}


void insertAfter(int value,int p)
{
    if(head == NULL)
    {
        cout<<"List is empty"<<endl;
        return;
    }

    NodePointer node = createNewNode(value);
    NodePointer current = head;
    while(current != NULL && current->data != p)
    {
        current = current->next;
    }

    if(current == NULL)
    {
        cout<<"Value "<<p<<" not found in the list"<<endl;
        return;
    }

    node->next = current->next;
    current->next = node;
}


void deleteFirst()
{
    if(head == NULL)
    {
        cout<<"List is empty"<<endl;
        return;
    }

    NodePointer node = head;
    head = head->next;
    delete node;
}


void deleteLast()
{
    if(head == NULL)
    {
        cout<<"List is empty"<<endl;
        return;
    }

    NodePointer prev = NULL;
    NodePointer current = head;
    while(current->next != NULL)

    {
        prev = current;
        current = current->next;
    }

    if(prev == NULL)
    {
        head = NULL;
        curr = NULL;
    }

    else
    {
        prev->next = NULL;
        curr = prev;
    }

    delete current;
}


 void deleteData(int p)
 {
    if(head == NULL)
    {
        cout<<"List is empty"<<endl;
        return;
    }

    NodePointer prev = NULL;
    NodePointer current = head;
    while(current != NULL && current->data != p)

    {
        prev = current;
        current = current->next;
    }

    if(current == NULL)

    {
        cout<<"Value "<<p<<" not found in the list"<<endl;
        return;
    }

    if(prev == NULL)
    {
        head = head->next;
    }

    else
    {
        prev->next = current->next;
    }

    if(current == curr)
    {
        curr = prev;
    }
    delete current;
}


void display()
{
    if(head == NULL)
    {
        cout<<"List is empty"<<endl;
        return;
    }

    NodePointer current = head;
    while(current != NULL)
    {
        cout<<current->data<<" ";
        current = current->next;
    }
    cout<<endl;
}


int main()
{
    //Insert 5 elements
    insertNelements(5);
    //Insert at the beginning
    insertAtFirst(10);
    //Insert at the end
    insertAtLast(20);
    //Insert before a node
    insertBefore(30, 3);
    //Insert after a node
    insertAfter(40, 2);
    //Display the list
    display();
    //Delete first node
    deleteFirst();
    //Delete last node
    deleteLast();
    //Delete node with value 30
    deleteData(30);
    //Display the list
    display();
    return 0;

}

