#include<iostream>
using namespace std;
//Structure for the Node
typedef class Node
{
public:
    int data;
    Node *next;
    Node(){}
    Node(T value){
        data = value;
        next = NULL;
    }
}* NodePointer;

//Declaring and initializing head and current node
NodePointer head=NULL,curr=NULL;

//Creating a Node with given value
NodePointer createNewNode(int value){

}

//insertion of N elements for the first time
void insertNelements(int n){

}
//insert a value as node at the Beginning of Linked List
void insertAtFirst(int value){

}

//insert a value as node at the End of Linked List
void insertAtLast(int value){

}

void insertBefore(int value, int p){


}
void insertAfter(int value,int p){

}

void deleteFirst(){

}

void deleteLast(){

}

void deleteData(int p){

}

void display(){

}


int main(){
    //Test your Linked List
return 0;
}
