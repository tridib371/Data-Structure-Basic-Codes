 #include<iostream>
using namespace std;

#define size 6
int A[size];
int front = -1;
int rear = -1;

bool isEmpty()

{

    if(front == -1 && rear == -1)

    {
        return true;
    }

    else

    {
        return false;
    }
}


bool isFull()

{
    if(rear == size - 1)

    {
        return true;
    }

    else

    {
        return false;
    }
}

void enqueue(int value)

{
    if(isFull())

    {
        cout << "QUEUE IS FULL \n";
    }

    else if(isEmpty())

    {
        front = 0;
        rear = 0;
        A[rear] = value;
    }

    else

    {
        rear++;
        A[rear] = value;
    }
}


void dequeue()

{

    if(isEmpty())
    {
        cout << "QUEUE IS EMPTY \n";
    }

    else if(front == rear)

    {
        front = -1;
        rear = -1;
    }

    else
    {
        front++;
    }
}


void frontValue()

{
    if(isEmpty())
    {
        cout << "QUEUE IS EMPTY \n";
    }

    else
    {
        cout << "ELEMENT AT FRONT IS : " << A[front] << endl;
    }
}


void showQueue()

{
    if(isEmpty())
    {
        cout << "QUEUE IS EMPTY \n";
    }

    else
    {
        for(int i = front; i <= rear; i++)
        {
            cout << A[i] << " ";
        }
        cout << endl;
    }
}


int main()
{
    enqueue(1);
    enqueue(5);
    enqueue(8);
    enqueue(3);
    showQueue();
    dequeue();
    showQueue();
    frontValue();
    dequeue();
    showQueue();

    return 0;
}
