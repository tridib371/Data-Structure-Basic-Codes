#include<iostream>
template<typename DType>
class LinkedList{
private:
    class Node{
    public:
        DType data;
        Node* next;

        Node(){}
        Node(DType data){
            this->data = data;
            this->next = NULL;
        }
    };

    Node* head = NULL;
    Node* curr = NULL;

    Node* createNode(DType data){ return new Node(data);}

public:
    void insertAtFirst(DType data){

        Node* newNode = createNode(data);

        if(head == NULL){
            head = newNode;
            curr = newNode;
        }
        else{
            newNode->next = head;
            head = newNode;
        }
    }

    void insertAtLast(DType data){
        if(head == NULL){
            insertAtFirst(data);
        }
        else{
            curr->next = createNode(data);
            curr = curr->next;
        }
    }

    //Complete the Methods
    void deleteAtLast(){}
    void deleteAtFirst(){}
    DType getLastElement(){}
    DType getFirstElement(){}

    void display(){
        Node* temp = head;
        while( temp !=NULL){
            std::cout<<temp->data<<std::endl;
            temp = temp->next;
        }
    }

};
