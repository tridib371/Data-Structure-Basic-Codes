#include <iostream>
#include "LinkedList.h"
namespace stackList
{
    // Assuming LinkedList implementation is defined here
}

template<typename DType>
class Stack
{
private:
    stackList::LinkedList<DType> myStackList;
public:
    Stack()
    {
    }

    void push(DType data)
    {
        myStackList.insertFront(data);
    }

    void pop()
    {
        if (!myStackList.isEmpty())
        {
            myStackList.removeFront();
        }
        else
        {
            std::cerr << "Stack is empty. Cannot pop." << std::endl;
        }
    }

    DType top()
    {
        if (!myStackList.isEmpty())
        {
            return myStackList.front();
        }
        else
        {
            std::cerr << "Stack is empty. Cannot return top." << std::endl;
            return DType();
        }
    }

    void display()
    {
        if (!myStackList.isEmpty())
        {
            std::cout << "Stack elements: ";
            myStackList.display();
        } else
        {
            std::cout << "Stack is empty." << std::endl;
        }
    }
};

int main()
{
    Stack<int> myStack;

    myStack.push(10);
    myStack.push(20);
    myStack.push(30);
    myStack.push(40);

    myStack.display();  // Stack elements: 40 30 20 10

    std::cout << "Top element: " << myStack.top() << std::endl;  // Top element: 40

    myStack.pop();
    myStack.pop();

    myStack.display();  // Stack elements: 20 10

    return 0;
}
