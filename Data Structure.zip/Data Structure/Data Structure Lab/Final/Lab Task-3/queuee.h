#include "LinkedList.h"

namespace queueList {
    template<typename DType>
    class Queue {
    private:
        LinkedList<DType> myQueueList;
    public:
        Queue() {}

        void enqueue(DType data) {
            myQueueList.insertAtLast(data);
        }

        void dequeue() {
            myQueueList.deleteAtFirst();
        }

        DType front() {
            return myQueueList.getFirstElement();
        }

        void display() {
            myQueueList.display();
        }
    };
}

template<typename DType>
using Queue = queueList::Queue<DType>;

