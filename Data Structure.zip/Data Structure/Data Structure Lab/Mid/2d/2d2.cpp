#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
     int x,y;
     cout<<" Enter your  1st matrix row size : ";
     cin>>x;
     cout<<"Enter your  1st matrix column size : ";
     cin>>y;

     int arr[x][y];
     for(int i=0;i<x;i++)
        {
          for(int j=0;j<y;j++)
          {
            cout<<"Enter 1st matrix row "<<i<<" column "<<j<<" value : ";
            cin>>arr[i][j];
          }
        }

    int n1,m1;
    cout<<"Enter 2nd matrix row : ";
    cin>>n1;
    cout<<"Enter 2nd matrix column : ";
    cin>>m1;

    int arr1[n1][m1];

    for(int i=0;i<n1;i++)
        {
        for(int j=0;j<m1;j++)
        {
            cout<<"Enter 2nd matrix row "<<i<<" column "<<j<<" value : ";
            cin>>arr1[i][j];
        }
    }
    cout<<" 1st Matrix is : "<<endl;
    for(int i=0;i<x;i++)
    {
        for(int j=0;j<y;j++)
        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<"2nd Matrix is : "<<endl;

    for(int i=0;i<n1;i++)
    {
        for(int j=0;j<m1;j++)
        {
            cout<<arr1[i][j]<<" ";
        }
        cout<<endl;
    }


    if(x==n1 && y==m1)
    {
        int arr2[x][m1];

        for(int i=0;i<x;i++)
        {
            for(int j=0;j<m1;j++)
            {
                arr2[i][j]=0;//important for specific result
            }
        }

        for(int i=0;i<x;i++)
        {
            for(int j=0;j<m1;j++)
            {
                arr2[i][j]=arr[i][j]+arr1[i][j];
            }
        }
        cout<<"Sum Matrix is : "<<endl;
        for(int i=0;i<x;i++)
        {
            for(int j=0;j<m1;j++)
            {
                cout<<arr2[i][j]<<" ";
            }
            cout<<endl;
        }
    }
    else
    {
        cout<<"Invalid combination of row and column. Summation not possible!"<<endl;
    }


    return 0;
}
