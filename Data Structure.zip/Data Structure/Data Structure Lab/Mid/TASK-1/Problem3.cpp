#include <iostream>
using namespace std;

int main()

{
    int a, b, n=0;
    cout<<"Enter size of the 1st array: ";
    cin>>a;
    cout<<"Enter size of the 2nd array: ";
    cin>>b;


    int Array1[a], Array2[b], Array3[max(a,b)];

    cout<<"\nPut the elements of 1st array: ";

    for(int i=0; i<a; i++)

    {
        cin >> Array1[i];
    }


    cout<<"\nPut the elements of 2nd array: ";

    for(int j=0; j<b; j++)

    {
        cin >> Array2[j];
    }


    for(int i = 0 ; i <a; i++)

    {
        for (int j = 0 ; j <b; j++)

        {
            if(Array1[i] == Array2[j])

            {
                Array3[n] = Array2[j];
                n++;
            }
        }
    }

    if(n == 0)

    {
        cout<<"\n\nNo Common Element"<<endl<<endl;
    }

    else

    {
        cout<<"\n\nThe common elements of both array are: "<<endl;


        for (int i = 0; i<n; i++)

        {
                cout << Array3[i] << " ";
        }

        cout<<endl<<endl;
    }

    return 0;
}
