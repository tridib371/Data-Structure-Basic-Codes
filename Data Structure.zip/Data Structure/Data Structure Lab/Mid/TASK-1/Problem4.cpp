#include <iostream>
using namespace std;

int main()

{

    int a, num,count = 0;

    cout<<"Enter size of the 1st array: ";
    cin>>a;



    int Array[a];

    cout<<"\nPlease enter the element of an array that store multiple of "<< num <<" is: ";

    for(int i=0; i<a; i++)

    {
        cin >> Array[i];
    }

   cout<<"Enter a number you want to search: ";
    cin>>num;

    for (int i = 0; i < a; i++)

    {
        if (Array[i] == num)

        {
            count++;
        }
    }

    cout << "The number occurs "<< count <<" times in the array." << endl;

    return 0;

}
