#include <iostream>
#include "arrayHelper.h"
using namespace std;

//Function to print a 1D array
void print1DArray(int *array, int size)
{
    for (int i = 0; i < size; i++)
    {
        cout << array[i] << " ";
    }
    cout << endl;
}



//Function to print a 1D array in reverse order
void reversePrint1DArray(int *array, int size)
{
    for (int i = size-1; i >= 0; i--)
    {
        cout << array[i] << " ";
    }
    cout << endl;
}



//Function to input elements in a 1D array
void input1DArray(int *array, int size)
{
    for (int i = 0; i < size; i++)
    {
        cin >> array[i];
    }
}



//Function to search for an element in a 1D array
int searchIn1DArray(int *array, int size, int searchKey)
{
    for (int i = 0; i < size; i++)
    {
        if (array[i] == searchKey)
        {
            return i;
        }
    }
    return -1; // Element not found
}




//Function to find the maximum element in a 1D array
int findMax1DArray(int *array, int size)
{
    int maxElement = array[0];
    for (int i = 1; i < size; i++)
    {
        if (array[i] > maxElement)
        {
            maxElement = array[i];
        }
    }
    return maxElement;
}




//Function to find the minimum element in a 1D array
int findMin1DArray(int *array, int size)
{
    int minElement = array[0];
    for (int i = 1; i < size; i++)
    {
        if (array[i] < minElement)
        {
            minElement = array[i];
        }
    }
    return minElement;
}




//Function to copy elements from one 1D array to another
void copy1DArray(int *sourceArray, int *destinationArray, int size)
{
    for (int i = 0; i < size; i++)
    {
        destinationArray[i] = sourceArray[i];
    }
}




//Function to sort a 1D array in ascending order using selection sort
void sort1DArray(int *array, int size)
{
    for (int i = 0; i < size-1; i++)
    {
        int minIndex = i;
        for (int j = i+1; j < size; j++)
        {
            if (array[j] < array[minIndex])
            {
                minIndex = j;
            }
        }
        int temp = array[minIndex];
        array[minIndex] = array[i];
        array[i] = temp;
    }
}




//Function to print a 2D array
void print2DArray(int **array, int row, int col)
{
    for (int i = 0; i < row; i++)
        {
        for (int j = 0; j < col; j++)
        {
            cout << array[i][j] << " ";
        }
        cout << endl;
    }
}



//Function to print a 2D array in reverse order
void reversePrint2DArray(int **array, int row, int col)
{
    for (int i = row-1; i >= 0; i--)
        {
        for (int j = col-1; j >= 0; j--)
        {
            cout << array[i][j] << " ";
        }
        cout << endl;
    }
}




//Function to input elements in a 2D array
void input2DArray(int **array, int row, int col)
{
    for (int i = 0; i < row; i++)
        {
        for (int j = 0; j < col; j++)
        {
            cin >> array[i][j];
        }
    }
}




//Function to search for an element in a 2D array
int searchIn2DArray(int **array, int row, int col, int searchKey)
{
    for (int i = 0; i < row; i++)
        {
        for (int j = 0; j < col; j++)
        {
            if (array[i][j] == searchKey)
            {
                return i*col + j;
            }
        }
    }
    return -1; // Element not found
}




//Function to find the maximum element in a 2D array
int findMax2DArray(int **array, int row, int col)
{
    int maxElement = array[0][0];
    for (int i = 0; i < row; i++)
        {
        for (int j = 0; j < col; j++)
        {
            if (array[i][j] > maxElement)
            {
                maxElement = array[i][j];
            }
        }
    }
    return maxElement;
}




//Function to find the minimum element in a 2D array
int findMin2DArray(int **array, int row, int col)
{
    int minElement = array[0][0];
    for (int i = 0; i < row; i++)
        {
        for (int j = 0; j < col; j++)
        {
            if (array[i][j] < minElement)
            {
                minElement = array[i][j];
            }
        }
    }
    return minElement;
}




//Function to copy elements from one 2D array to another
void copy2DArray(int **sourceArray, int **destinationArray, int row, int col)
{
    for (int i = 0; i < row; i++)
        {
        for (int j = 0; j < col; j++)
        {
            destinationArray[i][j] = sourceArray[i][j];
        }
    }
}


