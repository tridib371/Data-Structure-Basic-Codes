#include <iostream>
using namespace std;
int main()

{

    string j;
    cout<<"ENTER YOUR STRING HERE\n"<<endl;
    //getline(cin,j);
    cin>>j;


    for(int i=j.length()-1;i>=0;i--)

    {
        cout<<j[i];
    }

}
