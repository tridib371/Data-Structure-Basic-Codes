#include<iostream>
using namespace std;

int main()

{

    int b,t,sum=0;
    cout<<"Enter row number : ";
    cin>>b;

    cout<<"Enter column number: ";
    cin>>t;

    int arr[b][t];
    for(int i=0;i<b;i++)

        {

        for(int j=0;j<t;j++)

        {
            cout<<"Enter row "<<i<<" column "<<j<<" value : ";
            cin>>arr[i][j];
        }

    }

    cout<<"\nMatrix: "<<endl;
    for(int i=0;i<b;i++)

        {

        for(int j=0;j<t;j++)

        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }

    for(int i=0;i<b;i++)

        {

        for(int j=0;j<t;j++)

        {
            if(i==j || i+j==b-1)

            {
                sum+=arr[i][j];
            }
        }
    }

    cout<<"\nSum of the diagonal element: "<<sum;

    return 0;

}
