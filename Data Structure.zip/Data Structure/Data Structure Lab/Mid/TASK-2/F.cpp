#include<iostream>
using namespace std;

int main()

{
    int b,t,sum=0;

    cout<<"Enter size of the  1st matrix row : ";
    cin>>b;

    cout<<"Enter size of the 1st matrix column : ";
    cin>>t;

    int arr[b][t];
    for(int i=0;i<b;i++)

        {

        for(int j=0;j<t;j++)

        {
            cout<<"Enter 1st matrix row "<<i<<" column "<<j<<" value : ";
            cin>>arr[i][j];
        }

    }

    int b1,t1;
    cout<<"Enter size of the 2nd matrix row : ";
    cin>>b1;

    cout<<"Enter size of the 2nd matrix column : ";
    cin>>t1;

    int arr1[b1][t1];
    for(int i=0;i<b1;i++)

        {

        for(int j=0;j<t1;j++)

        {
            cout<<"Enter 1st matrix row "<<i<<" column "<<j<<" value : ";
            cin>>arr1[i][j];
        }

    }

    cout<<"\n1st Matrix: "<<endl;
    for(int i=0;i<b;i++)

        {

        for(int j=0;j<t;j++)

        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }


    cout<<"\n2nd Matrix: "<<endl;
    for(int i=0;i<b;i++)

        {

        for(int j=0;j<t;j++)

        {
            cout<<arr1[i][j]<<" ";
        }
        cout<<endl;

    }

    int arr2[b][t1];
    for(int i=0;i<b;i++)

        {

        for(int j=0;j<t1;j++)

        {
            for(int k=0;k<b;k++)

            {
                sum+=arr[i][k]*arr1[k][j];
            }

            arr2[i][j]=sum;
            sum=0;
        }
    }

    cout<<"\nMULTIPLICATION: "<<endl;
    for(int i=0;i<b;i++)

        {

        for(int j=0;j<t1;j++)

        {
            cout<<arr2[i][j]<<" ";
        }

        cout<<endl;
    }

    return 0;

}
