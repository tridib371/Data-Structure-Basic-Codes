#include<iostream>
using namespace std;

int main()

{
    int b,t,sum=0;
    cout<<"Enter the size of the row : ";
    cin>>b;

    cout<<"Enter size of thr column : ";
    cin>>t;

    int arr[b][t];
    for(int i=0;i<b;i++)

        {

        for(int j=0;j<t;j++)
        {

            cout<<"Enter row "<<i<<" column "<<j<<" value : ";
            cin>>arr[i][j];
        }

    }

    cout<<"\nMatrix: "<<endl;
    for(int i=0;i<b;i++)

        {
        for(int j=0;j<t;j++)

        {
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }

    for(int i=0;i<b;i++)

        {

        for(int j=0;j<t;j++)

        {
            if(i==0 || j==0 || i==b-1 || j==t-1)

            {
                sum+=arr[i][j];
            }
        }
    }

    cout<<"\nSum of the boundary element is : "<<sum;

    return 0;

}
