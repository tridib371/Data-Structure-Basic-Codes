#include<iostream>
using namespace std;

int main()
{
    int a, b;
    cout<<"Please Enter The Size of The Array: "<<endl;
    cin>>a>>b;

    int ar1[a][b], ar2[a][b], sum_ar[a][b];
    int sum;
    cout<<"Please Enter The Element Of First Array: "<<endl;
    for(int r=0; r<a; r++)
    {
        for(int c=0; c<b; c++)
        {
            cin>>ar1[r][c];
        }
        cout<<endl;
    }

    cout<<"Please Enter The Element Of Second Array: "<<endl;
    for(int r=0; r<a; r++)
    {
        for(int c=0; c<b; c++)
        {
            cin>>ar2[r][c];
        }
        cout<<endl;
    }

    cout<<"The First Array: "<<endl;
    for(int r=0; r<a; r++)
    {
        for(int c=0; c<b; c++)
        {
            cout<<ar1[r][c]<<"\t";
        }
        cout<<endl;
    }

    cout<<"The Second Array: "<<endl;
    for(int r=0; r<a; r++)
    {
        for(int c=0; c<b; c++)
        {
            cout<<ar2[r][c]<<"\t";
        }
        cout<<endl;
    }

    for(int r=0; r<a; r++)
    {
        for(int c=0; c<b; c++)
        {
            sum_ar[r][c]=ar1[r][c]+ar2[r][c];
        }
    }

    cout<<"Summation Of Two 2D Array: "<<endl;
    for(int r=0; r<a; r++)
    {
        for(int c=0; c<b; c++)
        {
            cout<<sum_ar[r][c]<<"\t";
        }
        cout<<endl;
    }

    return 0;
}

