#include <iostream>
using namespace std;

int main()

   {

    int b, t, i, j;
    cout << "Enter the size of rows of Matrix: ";
    cin >> b;


    cout << "Enter the size of column of  Matrix: ";
    cin >> t;

    int Matrix[b][t], TransposeMatrix[t][b];

    cout<<"\nPut the value of the Matrix: ";
    for (i = 0; i < b; i++)

    {
        for(j = 0; j < t; j++)

        {
            cin >> Matrix[i][j];
        }

    }

    cout<<"\nMatrix\n";

    for (i = 0; i < b; i++)

    {
        for(j = 0; j < t; j++)

        {
            cout << Matrix[i][j] << " ";
        }

        cout << endl;

    }

    for (i = 0; i < b; i++)

    {

        for(j = 0; j < t; j++)

        {
            TransposeMatrix[j][i] = Matrix[i][j];
        }

    }

    cout<<"\nTranspose Matrix\n";

    for (i = 0; i < t; i++)

    {

        for(j = 0; j < b; j++)

        {
            cout << TransposeMatrix[i][j] << " ";
        }

        cout << endl;
    }


    return 0;

}
