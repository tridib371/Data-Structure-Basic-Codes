#include<iostream>
using namespace std;

void initialize2DArray(int **arr,int row,int col,int v){
    //memoryAllocation
    for(int i=0;i<row;i++){
        arr[i] = new int [col];
    }
    //initialization
    for(int r=0;r<row;r++){
        for(int c=0;c<col;c++){
            arr[r][c]=v ;
        }
    }
}

void print2DArray(int **arr,int row,int col){
    for(int r=0;r<row;r++){
        for(int c=0;c<col;c++){
            cout<<arr[r][c]<<"\t" ;
        }
        cout<<endl;
    }
}

void input2DArray(int **arr,int row,int col){
    for(int r=0;r<row;r++){
        for(int c=0;c<col;c++){
            cin>>arr[r][c];
        }
    }
}

int main(){

    int row=3,col=3;
    //memory Allocation
    int **matA = new int*[row];
    initialize2DArray(matA,row,col,0);
    input2DArray(matA,row,col);
    print2DArray(matA,row,col);
/*
    cout<<"==================="<<endl;
    int **matB = new int*[5];
    initialize2DArray(matB,5,2,15);
    print2DArray(matB,5,2);
*/
}
