#include <iostream>
using namespace std;

int main()
{
    int row, column, a[100][100], b[100][100], sum[100][100], i, j;

    cout << "Enter number of rows: ";
    cin >> row;

    cout << "Enter number of columns: ";
    cin >> column;
    cout<<endl<<"-----------------------------------------";
    cout << endl << "Enter elements of 1st matrix: " << endl;
    cout<<"-----------------------------------------\n"<<endl;
    /// Storing elements of first matrix entered by user.
    for(i = 0; i < row; i++){
       for(j = 0; j < column; j++)
       {
           cout << "Enter element a" << i + 1 << j + 1 << " : ";
           cin >> a[i][j];
       }
    }

    /// Storing elements of second matrix entered by user.
    cout<<endl<<"-----------------------------------------";
    cout << endl << "Enter elements of 2nd matrix: " << endl;
    cout<<"-----------------------------------------\n"<<endl;
    for(i = 0; i < row; ++i)
       for(j = 0; j < column; ++j)
       {
           cout << "Enter element b" << i + 1 << j + 1 << " : ";
           cin >> b[i][j];
       }

    /// Adding Two matrices
    for(i = 0; i < row; ++i)
        for(j = 0; j < column; ++j)
            sum[i][j] = a[i][j] + b[i][j];

    /// Displaying the resultant sum matrix.
    cout << endl << "Sum of two matrix is: " << endl;
    for(i = 0; i < row; ++i)
        for(j = 0; j < column; ++j)
        {
            cout << sum[i][j] << "  ";
            if(j == column - 1)
                cout << endl;
        }

    return 0;
}
