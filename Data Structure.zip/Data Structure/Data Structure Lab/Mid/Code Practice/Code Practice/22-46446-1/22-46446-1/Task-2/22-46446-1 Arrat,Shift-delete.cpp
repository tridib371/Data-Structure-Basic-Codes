#include<iostream>
#include<stdlib.h>
using namespace std;

/* The following operations on array will be implemented:
    1. traverse
    2. search
    3. insertion
    4. deletion
*/

/*
    The following function defines traverse operation.
    It allows to visit all elements sequentially.
    Input: array, number of elements stored (s)
    Output: It will not return any value
*/
void traverse(int arr[], int s)
{
    cout<<"\nArray = [";
    for(int i=0; i <s-1; i++)
        cout<<arr[i]<<",";

    if(s <= 0)
        cout<<" ]\n";
    else
        cout<<arr[s-1]<<"]\n";
}

/*  Insertion function to insert an element given by user.
    Input: array, number of elements stored,
            the element to insert, the position or index to insert
    Output: It will not return any value but after calling this
    function, the number of elements must be increased by 1 in
    the main function.
*/
void insertion(int arr[], int s, int element, int ind){
    // check the necessary conditions for insertion
    //CODE
    // shifting the elements to right (starting from last element)
    for(int i=s; i>ind; i--){
        arr[i]=arr[i-1];
    }
    //inserting the element at index ind
    arr[ind]=element;
}

/*  Define search function here to search an element
    given by user.
    Input: array, number of elements stored, the element to search
    Output: It will return the index of the searching element found.
        If not found it will return -1.
*/
int searchElement(int arr[], int s, int element){

    int i;
    for(i=0; i<s; i++)
        if(arr[i]==element)
            return i;
        else
            return -i;
    }


/*  Define deletion function here to delete an element
    given by user.
    Input: array, number of elements stored, the position or index
    Output: It will not return any value but after calling this
    function, the number of elements must be decreased by 1 in
    the main function.
*/



void deletion(int arr[], int s, int index){
    for(int i=index;i<s;i++)
    {
      arr[i]=arr[i+1];
    }

}



int main()
{


    int ne,element,index;
    cout<< "\nHow many elements? ";
    cin>>ne;

    //Auto input
    int myArray[ne+10];
    for(int i=0; i<ne; i++)
        myArray[i] = rand()%100;
    traverse(myArray,ne);

    insertion(myArray,ne,11,5);
    ne++;


    /*cout<<"Which element do you want to insert : ";
    cin>>element;
    cout<<"Which index : ";
    cin>>index;
    insertion(myArray,ne,element,index);
    ne++;
    traverse(myArray,ne);*/


    // delete an element using deletion function here
    // CODE
     cout<<"Which index do you want to delete : ";
    cin>>index;
    deletion(myArray,ne,index);
    ne--;
    traverse(myArray,ne);


    //search an element using search function here
    // CODE

    cout<<"Which element do you want to find : ";
    cin>>element;
    index=searchElement(myArray,ne,element);
    if(index<0)
    {
        cout<< "Not found.";
    }
    else
    {
        cout<<"Found at index "<<index<<endl;
    }

    main();
}
