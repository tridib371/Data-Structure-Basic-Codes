#include<iostream>
using namespace std;

//Defining a BST node
struct node
{
    int data;
    node *left,*right;
};

node * root = NULL;

//declaration of all functions used in this code
node* insertData(int);
node *deleteData(node*,int);
node *searchData(int);
void visit(node*);
node *FindMin(node*);

int main()
{
    // populate BST with some values
    int elem,i;

    int a[]= {66,32,89,23,45,78,98,67};
    for(i=0; i<8; i++)
    {
        //cout<<"Element "<<i+1<<": ";
        //cin>>elem;
        if(insertData(a[i])== NULL)
            cout<<"Duplicated!! Insertion unsuccessful."<<endl<<endl;
    }

    cout<< "in-order: ";
    visit(root);

    FindMin(root);


    int choice;
    while(true)
    {
        cout<<"\n1) search data\n2) add data\n3) delete data\n4) show BST\n0) Exit\nEnter option: ";
        cin>>choice;
        switch(choice)
        {
        case 1:
            //use searchData function here
            cout<<"Which element to search? ";
            cin>>elem;
            if(searchData(elem))
                cout<<"found!\n";
            else
                cout<<"Not found!\n";
            break;
        case 2:
            //use insertData function here
            cout<<"Which element to insert? ";
            cin>>elem;
            if(insertData(elem))
                cout<<"Insertion successful."<<endl<<endl;
            else
                cout<<"Duplicated!! Insertion unsuccessful."<<endl<<endl;
            break;
        case 3:
            //use deleteData here
            cout<<"Which element to delete? ";
            cin>>elem;
            //call deleteData here
            if(deleteData(root,elem))
            {
                cout<<"Deleted"<<endl;
            }
            else
            {
                cout<<"Not Deleted"<<endl;
            }
            break;
        case 4:
            cout<< "in-order: ";
            visit(root);

            break;
        case 0:
            return 0;
        }
    }
    return 0;
}

//Defining a function to add a node in BST
node* insertData(int num)
{
    //create node
    node *nn=new node;
    nn->data=num;
    nn->left= nn->right = NULL;

    //traverse to the correct parent
    node *curr=root,*parent=NULL;
    while(curr!=NULL)
    {
        if(curr->data == num)
            return NULL;
        parent = curr;
        if(curr->data < num)
            curr=curr->right;
        else
            curr=curr->left;

    }

    // add the new node to parent
    if(root == NULL)
        root = nn;
    else if(parent->data < num)
        parent->right=nn;
    else
        parent->left=nn;

    return nn;
}

void visit(node *parent)//in-order traversal
{
    if(root == NULL)
        cout<<"Tree does not exist!\n\n";
    if(parent!=NULL)
    {
        visit(parent->left);
        cout<<parent->data<< " ";
        visit(parent->right);
    }

}

// Return the address of node where num is found
node *searchData(int num)
{
    if(root == NULL)
        cout<<"Tree does not exist!\n\n";
    else
    {
        //COMPLETE THE FUNCTION
        node *temp=root;
        while(temp!=NULL)
        {
            if(temp->data==num)
            {
                return temp;
            }
            else if(temp->data > num)
            {
                temp=temp->left;
            }
            else
            {
                temp=temp->right;
            }
        }
    }
    return NULL;

}
node *FindMin(node *SupNode)
{
    while(SupNode->left!=NULL)
    {
        SupNode=SupNode->left;
    }
    return SupNode;
}


node *deleteData(node *root,int num)
{
    if(root==NULL)
        return root;
    else if (num < root->data)
        root->left=deleteData(root->left,num);
    else if (num > root->data)
        root->right=deleteData(root->right,num);
    else
    {
        if(root->left==NULL && root->right==NULL)
        {
            delete root;
            root=NULL;

        }
        else if(root->left==NULL)
        {
            node *temp=root;
            root=root->right;
            delete temp;
        }
        else if(root-> right==NULL)
        {
            node *temp=root;
            root=root->left;
            delete temp;
        }
        else
        {
            node *temp=FindMin(root->right);
            root->data=temp->data;
            root->right=deleteData(root->right,temp->data);
        }
    }
    return root;

}

