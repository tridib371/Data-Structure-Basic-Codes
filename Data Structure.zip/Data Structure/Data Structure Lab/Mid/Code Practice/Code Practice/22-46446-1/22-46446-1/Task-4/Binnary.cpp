#include<iostream>
#include<stdlib.h>
using namespace std;

void print(int arr[], int s)
{
    cout<<"\nArray = [";
    for(int i=0; i <s-1; i++)
        cout<<arr[i]<<",";

    if(s <= 0)
        cout<<" ]\n";
    else
        cout<<arr[s-1]<<"]\n";
}

int bSearch(int arr[], int n, int key)
{   // if not found return -1
    int low = 0, high = n-1, mid;

    while(low<=high){
        mid = (low+high)/2;
        /*if conditions*/
        if(arr[mid] == key){
            return mid;
        }
        else if (arr[mid]<key)
        {
            low=mid+1;
        }
        else
        {
            high=mid-1;
        }
    }
     return -1;
}


int main()
{
    int ne;
    cout<< "\nHow many elements? ";
    cin>>ne;

    //Auto input
    int myArray[ne];
    myArray[0] = rand()%10;
    for(int i=1; i<ne; i++)
    {
        myArray[i] = myArray[i-1] + rand()%10;
    }
    print(myArray,ne);
    int item;
    cout<< "\nSearch? ";
    cin>>item;
    int pos = bSearch(myArray,ne,item);
    //print found or not found
    if(pos==-1)
        cout<<"\nNot found";
    else
        cout<<"\nfound";
    main();
}

