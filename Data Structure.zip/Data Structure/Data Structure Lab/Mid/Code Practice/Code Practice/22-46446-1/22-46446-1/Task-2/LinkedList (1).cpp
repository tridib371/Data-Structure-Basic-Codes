#include<iostream>
using namespace std;

struct MYNODE
{
    int data;
    MYNODE *next;
};

MYNODE *HEAD = NULL;

MYNODE* createNode(int v)
{
    MYNODE *NODE = new MYNODE();
    NODE->data = v;
    NODE->next = NULL;
    return NODE;
}

MYNODE* insert(int value, MYNODE *prev = NULL)
{
    MYNODE *NEWNODE = createNode(value);
    if (prev == NULL)
    {
        // insert at head
        NEWNODE->next = HEAD;
        HEAD = NEWNODE;
    }
    else
    {
        // after a previous node
        NEWNODE->next = prev->next;
        prev->next = NEWNODE;
    }
    return NEWNODE;
}

void traverse()
{
    MYNODE *curr = HEAD;
    while(curr)
    {
        cout<<curr->data<<"-->";
        curr = curr->next;
    }
    cout<<endl;
}

MYNODE* searchElement(int v)
{
    //return address of the node
    MYNODE *curr=HEAD;
    while (curr != NULL)
    {
        if (curr->data == v)
        {
            cout << "Found\n";
            return 0;
        }
        curr = curr->next;

    }
    cout <<"Number not found" << endl;
}


bool deleteElement(int v)

{
    //return true if deleted
    MYNODE* curr =HEAD;
    MYNODE* prev =NULL;

    if(HEAD->data==v){
        HEAD= HEAD->next;
        cout << "Successfully deleted \n";
        return 1;
    }

    prev=curr;
    curr=curr->next;
    cout << "Nothing to DELETE" << endl;
}


int main()
{
    MYNODE* curr = insert(5);
    curr =insert(3,curr);
    insert(8,curr);
    insert(9,curr);
    traverse();
    searchElement(7);
    traverse();
    searchElement(8);
    traverse();
    deleteElement(2);
    traverse();
    deleteElement(9);
    traverse();



}


