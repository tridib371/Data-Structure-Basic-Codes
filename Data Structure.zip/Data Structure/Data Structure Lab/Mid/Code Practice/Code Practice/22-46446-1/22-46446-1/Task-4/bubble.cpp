#include<iostream>
#include<stdlib.h>
using namespace std;

void print(int arr[], int s)
{
    cout<<"\nArray = [";
    for(int i=0; i <s-1; i++)
        cout<<arr[i]<<",";

    if(s <= 0)
        cout<<" ]\n";
    else
        cout<<arr[s-1]<<"]\n";
}

int bSort(int arr[], int n)
{
    for(int pass = 0; pass< n-1; pass++){
        for(int i = 0; i < n-pass-1; i++ ){
            if(arr[i]<arr[i+1]){
                swap(arr[i],arr[i+1]);
            }
        }
    }
}


int main()
{
    int ne;
    cout<< "\nHow many elements? ";
    cin>>ne;

    //Auto input
    int myArray[ne];

    for(int i=0; i<ne; i++)
    {
        myArray[i] = rand()%10;
    }
    print(myArray,ne);
    bSort(myArray,ne);
    print(myArray,ne);
    main();
}
