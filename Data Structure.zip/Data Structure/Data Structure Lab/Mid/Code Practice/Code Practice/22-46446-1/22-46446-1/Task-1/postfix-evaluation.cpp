#include<iostream>
#include<stack>
#include<queue>
using namespace std;

int main(){
    stack <float> st;
    queue <char> postfix;

    //read postfix expression with single digit only
    // example: 2 5 + 8 4 5 - + /
    cout<<"Enter postfix: ";
    char s;
    while(1){
        cin.get(s);
        if(s == ' ')continue;
        if(s == '\n')break;
        postfix.push(s);
    }

    //evaluate postfix
    while(!postfix.empty()){//2 5 + 9 6 - /
        s = postfix.front();
        postfix.pop();
        if(s == '+' || s == '-' || s == '*' || s=='/'){
            //CODE
            // pop twice and push once
            int temp;
            int a = (st.top());
            st.pop();
            int b = (st.top());
            st.pop();

            if(s == '+'){
                temp = a + b;
            }
            else if(s == '-'){
                temp = b - a;
            }
            else if(s == '*'){
                temp = a * b;
            }
            else if (s == '/'){
                temp = b / a;
            }

            cout<<"TEMP IS:"<<temp<<" \n";
            st.push(temp);
        }
        else{
             //CODE
             cout<<s<<' ';
             st.push(s - '0');
        }
    }

    cout<<"The value is "<< st.top();
    cout<<endl;

    return 0;
}
